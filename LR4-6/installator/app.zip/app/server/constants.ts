export const UNAUTHORIZED_STRING_MESSAGE: string = 'You don\'t have rights to this resource or action'

export const INVALID_QUERY_ARGUMENT_MESSAGE: string = 'Invalid query arguments for such request'