export const Main = (): JSX.Element => (
    <main className={'main welcome-promo page'}>
        <h1 className={'main__title'}>ISOB web app !</h1>
        <h2>© @user-of-github</h2>
    </main>
)
